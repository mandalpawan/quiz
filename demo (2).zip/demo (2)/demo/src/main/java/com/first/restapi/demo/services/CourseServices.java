package com.first.restapi.demo.services;

import java.util.List;

import com.first.restapi.demo.entities.Course;

public interface CourseServices {

	public List<Course> getCourse();
	
	public Course getCourseId(Long courseid);
	
	public Course addCourse(Course course);

	public Course updateCourse(Course course);
	
	public void deleteCourse(Long courseId);
	
}
