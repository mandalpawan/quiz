package com.first.restapi.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.first.restapi.demo.dao.Coursedao;
import com.first.restapi.demo.entities.Course;

@Service
public class CourseServiceImp implements CourseServices {
	
	List<Course> list;
	
	@Autowired
	Coursedao coursedao;
	
	
	public CourseServiceImp(){
//		list = new ArrayList<>();
//		list.add(new Course(111,"Name","Disc"));
	}
	
	@Override
	public List<Course> getCourse() {
		// TODO Auto-generated method stub
//		return list;
		return coursedao.findAll();
	}

	@Override
	public Course getCourseId(Long courseId) {
//		Course data = null;
//		for(Course c : list) {
//			if(c.getId()==courseId) {
//				data = c;
//				break;
//			}
//		}
//		return data;
		return coursedao.getOne(courseId);
	}

	@Override
	public Course addCourse(Course course) {
//		list.add(course);
		coursedao.save(course);
		return course;
	}

	@Override
	public Course updateCourse(Course course) {
		
//		list.forEach(e ->{
//			if(e.getId()==course.getId()) {
//				e.setDiscription(course.getDiscription());
//				e.setTitle(course.getTitle());
//			}
//		});
		coursedao.save(course);
		return course;
	}

	@Override
	public void deleteCourse(Long courseId) {
//		list = this.list.stream().filter(e -> e.getId()!=courseId).collect(Collector.toList());
		Course course = coursedao.getOne(courseId);
		coursedao.delete(course);
		
	}
	
	

}
