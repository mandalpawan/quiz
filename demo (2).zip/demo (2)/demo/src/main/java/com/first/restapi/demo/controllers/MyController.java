package com.first.restapi.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.first.restapi.demo.entities.Course;
import com.first.restapi.demo.entities.Product;
import com.first.restapi.demo.services.CourseServices;

@RestController
public class MyController {
	
	@Autowired
	private CourseServices coServices;

	@GetMapping("/home")
	public String home() {
		return "Home Page";
	}
	
	
//	for getting course.
	@GetMapping("/course")
	public List<Course> getCourses(){
		return this.coServices.getCourse();
	}
	
	@GetMapping("/course/{courseId}")
	public Course getCourseById(@PathVariable String courseId){
		return this.coServices.getCourseId(Long.parseLong(courseId));
	}
	
	@PostMapping("/course")
	public Course addCourses(@RequestBody Course course){
		return this.coServices.addCourse(course);
	}
	
	@PutMapping("/course")
	public Course updateCourse(@RequestBody Course course) {
		return this.coServices.updateCourse(course);
	}
	
	@DeleteMapping("/course/{courseId}")
	public ResponseEntity<HttpStatus> deleteCourse(@PathVariable String courseId){
		try {
			this.coServices.deleteCourse(Long.parseLong(courseId));
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
//	@PostMapping("/api/products")
//    public void createProduct(@RequestBody Product product) {
//        System.out.print(product);
//        
//    }
	
	
}
