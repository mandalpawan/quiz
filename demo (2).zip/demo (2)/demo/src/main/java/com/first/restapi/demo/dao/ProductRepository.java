package com.first.restapi.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.first.restapi.demo.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
    // Additional query methods if needed
}
