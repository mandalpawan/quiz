package com.first.restapi.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.first.restapi.demo.dao.ProductRepository;
import com.first.restapi.demo.entities.Product;

@Service
public class ProductServices {

    @Autowired
    private ProductRepository productRepository;

    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
    // Other service methods
}
