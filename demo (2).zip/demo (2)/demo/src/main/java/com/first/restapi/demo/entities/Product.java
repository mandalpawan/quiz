package com.first.restapi.demo.entities;

import java.util.HashMap;
import java.util.Map;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MapKeyColumn;

@Entity
public class Product {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // Common fields
    private String sku;

    // Fields for multiple languages
    @ElementCollection
    @MapKeyColumn(name = "language")
//    @CollectionTable(name = "product_name", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "name")
    private Map<String, String> names = new HashMap<>();

    // Other fields and methods
}
